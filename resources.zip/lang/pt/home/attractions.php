<?php

return [
    'title' => 'Atrações Favoritas',
    'hover1' => 'Saber Mais',
    'hover2' => 'A sua jornada começa aqui!'
];
