<?php


return [

    'welcome' => 'Bem vindo!',
    'admin_painel' => 'Painel de Admin',

];
