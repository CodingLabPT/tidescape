<?php

return[
    'title'            => 'Adicionar nova marca',
    'image'            => 'Imagem',
    'drag_and_drop'    => 'Clique ou arraste para carregar',
    'name'             => 'Nome desejado para a marca',
    'name_placeholder' => 'Nome desejado',
    'url'              => 'Endereço de Destino',
    'url_placeholder'  => 'Introduza aqui o url completo',
    'submit_btn'       => 'Adicionar',
    'go_back_btn'      => 'Voltar',
];
