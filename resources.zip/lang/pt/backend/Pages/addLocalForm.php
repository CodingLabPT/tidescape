<?php

return[
    'title'            => 'Adicionar nova localidade',
    'name_placeholder'  => 'Localidade desejada',
    'submit_btn'        => 'Adicionar',
    'go_back_btn'       => 'Voltar',
];
