<?php

return [
    'title' => 'Lista de "<i>Brands</i>"',
    'no_results' => 'Sem nenhuma <i>brand</i> de momento',
    'add' => 'Adicionar marca',
    'name' => 'Nome',
    'logo' => 'Logo',
    'url' => 'URL',
    'acoes' => 'Ações',
    'apagar' => 'Apagar',
    'sure' => 'Tem certeza de que deseja excluir?',
    'delete_successfully' => 'Marca eliminada com sucesso!',
    'created_successfully' => 'Marca criada com sucesso!',
];
