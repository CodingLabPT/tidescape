<?php

return [
    'title'            => 'Agregar nueva marca',
    'image'            => 'Imagen',
    'drag_and_drop'    => 'Haga clic o arrastre para cargar',
    'name'             => 'Nombre deseado para la marca',
    'name_placeholder' => 'Nombre deseado',
    'url'              => 'URL de destino',
    'url_placeholder'  => 'Introduzca aquí la URL completa',
    'submit_btn'       => 'Agregar',
    'go_back_btn'      => 'Volver',
];
