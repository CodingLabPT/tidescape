<?php


return [
    'title' => 'Correos electrónicos registrados en el Boletín informativo',
    'export' => 'Exportar datos',
    'no_newsletters' => 'No hay usuários registrados en el Boletín informativo',
    'name' => 'Nombre',
    'phone' => 'Telefóno',
    'Status' => 'Estatus',
    'opt' => 'Opciones',
    'delete' => 'Borrar',
    'reserve_detail' => 'Detalles',
    'delete_reserve' => 'Borrar',

    'email' => "Correo electrónico",
    'go_back' => 'Volver',
    'are_you_sure_to_delete' => '¿Estás seguro de borrar?',

];
