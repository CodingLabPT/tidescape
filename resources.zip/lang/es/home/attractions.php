<?php


return [

    'title' => 'Atracciones favoritas',
    'hover1' => 'Saber más',
    'hover2' => 'Tu viaje comienza aquí!'
];
