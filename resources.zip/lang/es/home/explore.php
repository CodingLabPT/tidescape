<?php


return [

    'title' => 'Increíbles experiencias en barco',
    'hover' => 'Saber más',

];
