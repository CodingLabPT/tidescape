<?php

return [
    "title" => "List of Users",
    'export' => 'Export data',
    'no_users' => 'No users available at the moment.',
    'name' => 'Name',
    'phone' => 'Phone',
    'Status' => 'Status',
    'opt' => 'Options',
    'delete' => 'Delete',
    'reserve_detail' => 'Details',
    'delete_reserve' => 'Delete',

    'email' => "Email",
    'go_back' => 'Go back',
    'are_you_sure_to_delete' => 'Are you sure to delete?',

];
