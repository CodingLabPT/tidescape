<?php


return [

    'title' => 'Favourite attractions',
    'hover1' => 'Know More',
    'hover2' => 'Your journey starts here!'
];
