<li><a href="{{ route('category') }}">{{ __('menu.tours') }}</a></li>
<li><a href="{{ route('offers') }}"> {{ __('menu.offers') }} </a></li>
<li><a href="{{ route('accomodations') }}">{{ __('menu.acommodations') }} </a></li>
<li><a href="{{ route('contacts') }}"> {{ __('menu.contacts') }} </a></li>
