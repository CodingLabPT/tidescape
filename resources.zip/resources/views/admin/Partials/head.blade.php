<!-- favicon -->
<link rel=icon href="{{ asset('assets/img/logo-favicon.png') }}" sizes="16x16" type="icon/png">
<!-- bootstrap -->
<link rel="stylesheet" href="{{ asset('../../assets/css/bootstrap.min.css') }}">
<!-- FontAwesome -->
<link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
<!-- Main Stylesheet -->
<link rel="stylesheet" href="{{ asset('../../assets/css/style.css') }}">
<!-- Main Stylesheet -->
<link rel="stylesheet" href="{{ asset('../../assets/css/geral.css') }}">
<!-- Scripts -->
<!-- Language selector Stylesheet -->
<link rel="stylesheet" href="{{ asset('assets/css/languageSelector.css') }}">
@vite(['resources/css/app.css', 'resources/js/app.js'])
