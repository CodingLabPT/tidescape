<?php

return [
    'home' => 'inicio',
    'get_in_touch' => 'Contacta con nosotros',
    'friendly_team' => 'Nuestro amable equipo estaría encantado de saber de ti.',
    
    'fn_error' => '¡Por favor, ingrese su nombre!',
    'ln_error' => '¡Por favor, ingrese su apellido!',
    'email_error' => '¡Por favor, ingrese su correo electrónico!',
    'invalid_email_error' => '¡Por favor, ingrese un correo electrónico válido!',
    'phone_error' => '¡Por favor, ingrese su número de teléfono!',
    'mensage_error' => '¡Por favor, ingrese su primer mensaje!'

];
