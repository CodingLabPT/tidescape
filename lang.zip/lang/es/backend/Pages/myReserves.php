<?php

return [
    'title' => 'Mis Reservas',
    'no' => '¡Sin reservas por el momento!',
    'delete' => '¡Reserva cancelada con éxito!',
];
