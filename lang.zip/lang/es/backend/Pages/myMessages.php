<?php

return [
    'title' => 'Mis Mensajes',
    'no' => '¡No hay mensajes disponibles!',
    'delete' => '¡Mensaje eliminado con éxito!',
];
