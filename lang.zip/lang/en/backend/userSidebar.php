<?php

return [
    'booking_management' => 'Booking Management',
    'my_booking' => 'My Bookings',
    'calendar' => 'Calendar',

    'contacts' => 'Contacts',
    'my_messages' => 'My Messages',
    'newsletter' => 'Newsletter',
    'my_reserves' => 'My Reservations',
    'sem_registo' => 'Not Registered',
    'com_registo' => 'Registered',

    'profile' => 'Profile',
    'sair' => 'Logout',
];
