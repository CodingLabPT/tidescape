<?php

return [
    'title' => 'My Messages',
    'no' => 'No messages available!',
    'delete' => 'Message successfull Deleted!',
];
