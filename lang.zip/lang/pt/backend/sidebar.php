<?php

return [
    'booking_management' => 'Gestão de Reservas',
    'booking' => 'Reservas',
    'Calendar' => 'Calendário',
    'Users' => 'Utilizadores',
    'Admins' => 'Administradores',
    'Newsletter' => 'Newsletter',
    'Messages' => 'Mensagens',

    'Tours' => 'Passeios',
    'Tours2' => 'Passeios',

    'Categories' => 'Categorias',
    'Local' => 'Local',
    'Duration' => 'Duração',
    'Management' => 'Gestão',
];
