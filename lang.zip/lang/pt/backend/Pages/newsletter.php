<?php

return [
    'title' => 'Emails Registados no Boletim Informativo',
    'export' => 'Exportar Dados',
    'no_newsletters' => 'Não há utilizadores registados no Boletim Informativo',
    'name' => 'Nome',
    'phone' => 'Telefone',
    'Status' => 'Estado',
    'opt' => 'Opções',
    'delete' => 'Apagar',
    'reserve_detail' => 'Detalhes',
    'delete_reserve' => 'Apagar',

    'email' => "Email",
    'go_back' => 'Voltar',
    'are_you_sure_to_delete' => 'Tem a certeza que deseja apagar?',

];
