<?php

return[

    'title' => 'Minhas reservas',
    'no' => 'Sem reservas de momento!!',
    'delete' => 'Reserva cancelada com sucesso!',
];
