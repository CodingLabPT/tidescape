<?php

return [
    "title" => "Lista de Utilizadores",
    'export' => 'Exportar dados',
    'no_users' => 'Não há utilizadores disponíveis neste momento.',
    'name' => 'Nome',
    'phone' => 'Telefone',
    'Status' => 'Estado',
    'opt' => 'Opções',
    'delete' => 'Apagar',
    'reserve_detail' => 'Detalhes',
    'delete_reserve' => 'Apagar',

    'email' => "Endereço de Email",
    'go_back' => 'Voltar',
    'are_you_sure_to_delete' => 'Tem a certeza de que deseja apagar?',

];
