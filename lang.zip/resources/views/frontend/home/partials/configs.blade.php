<!-- back to top area start -->
<div class="back-to-top bg-color-two">
    <span class="back-top"> <i class="las la-angle-up"></i> </span>
</div>
<!-- back to top area end -->

<!-- Mouse Cursor start -->
<div class="mouse-cursor-two">
    <div class="mouse-move mouse-outer bg-color-two"></div>
    <div class="mouse-move mouse-inner bg-color-two"></div>
</div>
<!-- Mouse Cursor Ends -->

<!-- jquery -->
<script src="{{ asset('assets/js/jquery-3.6.0.min.js') }} "></script>
<!-- jquery Migrate -->
<script src="{{ asset('assets/js/jquery-migrate.min.js') }} "></script>
<!-- bootstrap -->
<script src="{{ asset('assets/js/bootstrap.bundle.min.js') }} "></script>
<!-- Wow Js -->
<script src="{{ asset('assets/js/wow.js') }} "></script>
<!-- Slick Js -->
<script src="{{ asset('assets/js/slick.js') }} "></script>
<!-- ImageLoaded Js -->
<script src="{{ asset('assets/js/imagesloaded.pkgd.min.js') }} "></script>
<!-- Isotope Js -->
<script src="{{ asset('assets/js/isotope.pkgd.min.js') }} "></script>
<!-- Magnific Popup Js -->
<script src="{{ asset('assets/js/jquery.magnific-popup.js') }} "></script>
<!-- Nice Select Js -->
<script src="{{ asset('assets/js/jquery.nice-select.js') }} "></script>
<!-- Flat Picker Js -->
<script src="{{ asset('assets/js/flatpicker.js') }} "></script>
<!-- Range Slider Js -->
<script src="{{ asset('assets/js/nouislider-8.5.1.min.js') }} "></script>
<!-- main js -->
<script src="{{ asset('assets/js/main.js') }} "></script>