<?php

return [
    'newsletter_subject'         => 'Suscripción a la newsletter',
    'reserves_subject'           => 'Reserva pendiente de confirmación',
    'register_subject'           => 'Registro realizado con éxito',
    'contact_subject'            => 'Envío de mensaje del formulario de contacto',
    'contact_response_subject'   => 'Respuesta al mensaje del formulario de contacto',
    'validation_reserve_subject' => 'Reserva validada',
    'admin_reserve_subject'      => '¡Reserva realizada por el administrador!',
    'admin_register_subject'     => '¡Registro realizado por el administrador!',
];
