<?php

return [

    'newsletter_error'   => '¡Este correo electrónico ya está suscrito a nuestro boletín!',
    'newsletter_success' => '¡Gracias por suscribirte a nuestro boletín!',

];
