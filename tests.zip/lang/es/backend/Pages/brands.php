<?php

return [
    'title' => 'Lista de "<i>Marcas</i>"',
    'no_results' => 'Sin ninguna <i>marca</i> por el momento',
    'add' => 'Agregar Marca',
    'name' => 'Nombre',
    'logo' => 'Logo',
    'url' => 'URL',
    'acoes' => 'Acciones',
    'apagar' => 'Eliminar',
    'sure' => '¿Está seguro de que desea eliminar?',
    'delete_successfully' => '¡Marca eliminada con éxito!',
    'created_successfully' => '¡Marca creada con éxito!',
];
