<?php

return[
    "title" => "Listado de Usuários",
    'export' => 'Exportar datos',
    'no_users' => 'No hay usuários disponibles en este momento.',
    'name' => 'Nombre',
    'phone' => 'Telefóno',
    'Status' => 'Estatus',
    'opt' => 'Opciones',
    'delete' => 'Borrar',
    'reserve_detail' => 'Detalles',
    'delete_reserve' => 'Borrar',

    'email' => "Correo electrónico",
    'go_back' => 'Volver',
    'are_you_sure_to_delete' => '¿Estás seguro de borrar?',

];
