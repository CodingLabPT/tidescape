<?php

return [
    'title'            => 'Agregar nuevo tipo de embarcación',
    'title1'           => 'Embarcaciones',
    'title2'           => 'Agregar',
    'principal_image'  => 'Imagen principal',
    'adicional_image'  => 'Imagen adicional',
    'drag_and_drop'    => 'Haga clic o arrastre para cargar',
    'name'             => 'Nombre deseado para la embarcación',
    'name_placeholder' => 'Nombre deseado',
    'desc'             => 'Pequeña descripción para el tipo de embarcación',
    'desc_placeholder' => 'Pequeña descripción',
    'submit_btn'       => 'Agregar',
    'go_back_btn'      => 'Volver',
];
