<?php

return [
    'title'            => 'Add new vessel type',
    'title1'           => 'Vessels',
    'title2'           => 'Add',
    'principal_image'  => 'Main image',
    'adicional_image'  => 'Additional image',
    'drag_and_drop'    => 'Click or drag to upload',
    'name'             => 'Desired name for the vessel',
    'name_placeholder' => 'Desired name',
    'desc'             => 'Short description for the vessel type',
    'desc_placeholder' => 'Short description',
    'submit_btn'       => 'Add',
    'go_back_btn'      => 'Go back',
];
