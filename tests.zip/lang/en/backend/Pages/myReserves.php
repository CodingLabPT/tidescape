<?php

return [
    'title' => 'My Reserves',
    'no' => 'No reserves at the moment!',
    'delete' => 'Reserve successfully cancelled!',
];
