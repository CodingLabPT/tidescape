<?php

return [
    'title' => 'List of "<i>Brands</i>"',
    'no_results' => 'No <i>brands</i> at the moment',
    'add' => 'Add Brand',
    'name' => 'Name',
    'logo' => 'Logo',
    'url' => 'URL',
    'acoes' => 'Actions',
    'apagar' => 'Delete',
    'sure' => 'Are you sure to delete?',
    'delete_successfully' => 'Brand deleted successfully!',
    'created_successfully' => 'Brand created successfully!',
];
