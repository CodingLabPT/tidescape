<?php

return [
    'title1'            => 'Add',
    'title2'            => 'Add new duration in hours',
    'name_placeholder'  => 'desired duration (hours)',
    'submit_btn'        => 'Add',
    'go_back_btn'       => 'Go back',
];
