<?php

return [

    'newsletter_error'   => 'This email is already subscribed to our newsletter!',
    'newsletter_success' => 'Thank you for subscribing to our newsletter!',

];
