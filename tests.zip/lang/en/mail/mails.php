<?php

return [
    'newsletter_subject'         => 'Newsletter Subscription',
    'reserves_subject'           => 'Pending Reservation Confirmation',
    'register_subject'           => 'Registration Successful',
    'contact_subject'            => 'Message Sent from Contact Form',
    'contact_response_subject'   => 'Response to Contact Form Message',
    'validation_reserve_subject' => 'Reservation Validated',
    'admin_reserve_subject'      => 'Reservation Made by Admin!',
    'admin_register_subject'     => 'Registration Made by Admin!',
];
