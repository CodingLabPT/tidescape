<?php


return [

    'welcome' => 'welcome',
    'admin_painel' => 'Admin Painel',

];
