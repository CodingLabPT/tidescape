<?php

return [
    'title' => 'Book Events Tours or Travels for your next adventure',
    'subtitle' => 'Explore and create memories effortlessly with our platform, where the world is your next destination!',
    'number' => '4.8/5(2380)',
    'reviews' => 'Trustpilot reviews',
];
