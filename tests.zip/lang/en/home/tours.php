<?php

return [
   'title' => 'Nearby Tours',
   'since' => 'Since',
   'book_now' => 'Book Now',
   'no_tours' => 'No tours available at the moment!',
];
