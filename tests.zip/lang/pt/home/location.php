<?php


return [

    'title' => 'Localização',
    'dropdown_title' => 'Selecione a locatização',
    'no_location' => 'Por favor, selecione uma localização!'
];
