<?php

return [
    'booking_management' => 'Gestão de Reservas',
    'my_booking' => 'Minhas Reservas',
    'calendar' => 'Calendário',

    'contacts' => 'Contactos',
    'my_messages' => 'Minhas mensagens',
    'newsletter' => 'Newsletter',
    'my_reserves' => 'Minhas reservas',
    'sem_registo' => 'Sem registo',
    'com_registo' => 'Registado',

    'profile' => 'Perfil',
    'sair' => 'Sair',
];
