<script src="{{ asset('assets/js/jquery-3.6.0.min.js') }}"></script>
<!-- jquery Migrate -->
<script src="{{ asset('assets/js/jquery-migrate.min.js') }}"></script>
<!-- bootstrap -->
<script src="{{ asset('assets/js/bootstrap.bundle.min.js') }}"></script>
<!-- Wow Js -->
<script src="{{ asset('assets/js/wow.js') }}"></script>
<!-- Slick Js -->
<script src="{{ asset('assets/js/slick.js') }}"></script>
<!-- ImageLoaded Js -->
<script src="{{ asset('assets/js/imagesloaded.pkgd.min.js') }}"></script>
<!-- Isotope Js -->
<script src="{{ asset('assets/js/isotope.pkgd.min.js') }}"></script>
<!-- Magnific Popup Js -->
<script src="{{ asset('assets/js/jquery.magnific-popup.js') }}"></script>
<!-- Nice Select Js -->
<script src="{{ asset('assets/js/jquery.nice-select.js') }}"></script>
<!-- Flat Picker Js -->
<script src="{{ asset('assets/js/flatpicker.js') }}"></script>
<!-- Range Slider Js -->
<script src="{{ asset('assets/js/nouislider-8.5.1.min.js') }}"></script>
<!-- main js -->
<script src="{{ asset('assets/js/main.js') }}"></script>

<script src="{{ asset('assets/phone/js/intlTelInput.js') }}"></script>

<script>
    var input = document.querySelector("#phone");
    window.intlTelInput(input,{});
</script>

<!-- CDN Jquery-->
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

<!-- JS DataTable-->
<script src="//cdn.datatables.net/2.0.0/js/dataTables.min.js"></script>

<script>
    let table = new DataTable('#myTable');;
</script>
