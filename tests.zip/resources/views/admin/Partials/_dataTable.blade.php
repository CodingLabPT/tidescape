<!-- CDN DataTable-->
<link rel="stylesheet" href="//cdn.datatables.net/2.0.0/css/dataTables.dataTables.min.css">


<!-- CDN Jquery-->
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

<!-- JS DataTable-->
<script src="//cdn.datatables.net/2.0.0/js/dataTables.min.js"></script>

<script>
    let table = new DataTable('#myTable');;
</script>
