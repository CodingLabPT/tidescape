<?php


return [
    'locales' => [
        'pt',
        'en',
        'es',
    ]
];
