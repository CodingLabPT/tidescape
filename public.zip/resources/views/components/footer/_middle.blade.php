<div class="container">
    <div class="footer-widget widget">
        <div class="footer-widget-nav">
            <ul class="footer-widget-nav-list list-style-none text-center">
                <li class="footer-widget-nav-list-item">
                    <a href="javascript:void(0)" class="footer-widget-nav-list-link">  </a>
                </li>
                <li class="footer-widget-nav-list-item">
                    <a href="{{ route('info') }}" class="footer-widget-nav-list-link"> {{ __('footer.terms_of_use') }} </a>
                </li>
                <li class="footer-widget-nav-list-item">
                    <a href="{{ route('policy') }}" class="footer-widget-nav-list-link"> {{ __('footer.privacy_politicy') }} </a>
                </li>
                <li class="footer-widget-nav-list-item">
                    <a href="{{ route('contacts') }}" class="footer-widget-nav-list-link"> {{ __('footer.contacts') }} </a>
                </li>
                <li class="footer-widget-nav-list-item">
                    <a href="javascript:void(0)" class="footer-widget-nav-list-link"> </a>
                </li>
            </ul>
        </div>
    </div>
</div>
