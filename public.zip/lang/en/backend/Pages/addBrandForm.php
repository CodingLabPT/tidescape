<?php

return [
    'title'            => 'Add new brand',
    'image'            => 'Image',
    'drag_and_drop'    => 'Click or drag to upload',
    'name'             => 'Desired name for the brand',
    'name_placeholder' => 'Desired name',
    'url'              => 'Destination URL',
    'url_placeholder'  => 'Enter the full URL here',
    'submit_btn'       => 'Add',
    'go_back_btn'      => 'Go back',
];
