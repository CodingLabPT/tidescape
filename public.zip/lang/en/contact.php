<?php

return [
    'home' => 'Home',
    'get_in_touch' => 'Get in touch',
    'friendly_team' => 'Our friendly team would love to hear from you!',
    
    'fn_error' => 'Please, fill your first name!',
    'ln_error' => 'Please, fill your last name!',
    'email_error' => 'Please, fill your email!',
    'invalid_email_error' => 'Please, fill an valid email!',
    'phone_error' => 'Please, fill your phone number!',
    'mensage_error' => 'Please, fill your first mensage!'
];
