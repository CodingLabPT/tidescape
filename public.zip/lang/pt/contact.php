<?php

return [
    'home' => 'Início',
    'get_in_touch' => 'Entre em Contato',
    'friendly_team' => 'Nossa equipe simpática adoraria ouvir você!',
    
    'fn_error' => 'Por favor preencha o seu primeiro nome!',
    'ln_error' => 'Por favor preencha o seu ultimo nome!',
    'email_error' => 'Por favor, informe um email valido!',
    'invalid_email_error' => 'Por favor, informe um email valido!',
    'phone_error' => 'Por favor, informe o seu contacto telefónico!',
    'mensage_error' => 'Por favor, preencha a sua mensagem!'
];
