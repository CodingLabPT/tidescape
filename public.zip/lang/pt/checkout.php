<?php

return [
    'checkout_details' => 'Detalhes do Pagamento',
    'reserve_information' => 'Informações da Reserva',
    'submit' => 'Enviar',
    'tour_details' => 'Detalhes do Tour',
    'tour_name' => 'Nome do Tour',
    'date' => 'Data',
    'desired_boat' => 'Barco Desejado',
    'price' => 'Preço',
    'checkout' => 'Pagamento',
];
