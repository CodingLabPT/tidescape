<?php

return[
    'title'            => 'Adicionar novo tipo de embarcação',
    'title1'           => 'Embarcações',
    'title2'           => 'Adicionar',
    'principal_image'  => 'Imagem principal',
    'adicional_image'  => 'Imagem adicional',
    'drag_and_drop'    => 'Clique ou arraste para carregar',
    'name'             => 'Nome desejado para a embarcação',
    'name_placeholder' => 'Nome desejado',
    'desc'             => 'Pequena descrição para o tipo de embarcação',
    'desc_placeholder' => 'Pequena descrição',
    'submit_btn'       => 'Adicionar',
    'go_back_btn'      => 'Voltar',
];
