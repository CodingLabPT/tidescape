<?php

return [
    'title' => 'Tours Próximos',
    'since' => 'Desde',
    'book_now' => 'Reservar Agora',
    'no_tours' => 'Sem tours até ao momento!',
];
