<?php

return [
    'title' => 'Experiências de barco incríveis',
    'hover' => 'Saber Mais',
];
