<?php

return [
    'title' => 'Reserve Eventos, Tours ou Viagens para a sua próxima aventura',
    'subtitle' => 'Explore e crie memórias sem esforço com a nossa plataforma, onde o mundo é o seu próximo destino!',
    'number' => '4.8/5(2380)',
    'reviews' => 'Avaliações no Trustpilot',
];
