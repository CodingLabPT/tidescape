<?php

return [
    'title' => 'Tours cercanos',
    'since' => 'Desde',
    'book_now' => 'Reservar Ahora',
    'no_tours' => '¡Sin tours disponibles por el momento!',
];
