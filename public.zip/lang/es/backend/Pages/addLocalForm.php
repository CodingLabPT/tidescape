<?php

return [
    'title'            => 'Agregar nueva localidad',
    'name_placeholder'  => 'Localidad deseada',
    'submit_btn'        => 'Agregar',
    'go_back_btn'       => 'Volver',
];
