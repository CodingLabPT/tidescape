<?

return[
    'checkout_details' => 'Detalles del pago',
    'reserve_information' => 'Información de la Reserva',
    'submit' => 'Enviar',
    'tour_details' => 'Detalles del Tour',
    'tour_name' => 'Nombre del Tour',
    'date' => 'Data',
    'desired_boat' => 'Barco Deseado',
    'price' => 'Precio',
];
