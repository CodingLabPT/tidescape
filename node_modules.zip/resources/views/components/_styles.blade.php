<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>
<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css"/>
<link rel="stylesheet" href="{{ asset('assets/phone/css/demo.css') }}">
<link rel="stylesheet" href="{{ asset('assets/phone/css/intlTelInput.css') }}">

<!-- favicon -->
<link rel=icon href="{{ asset('assets/img/logo-favicon.png') }}" sizes="16x16" type="icon/png">
<!-- bootstrap -->
<link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">
<!-- FontAwesome -->
<link rel="stylesheet" href="{{ asset('assets/css/line-awesome.min.css') }}">
<!-- Animate Css -->
<link rel="stylesheet" href="{{ asset('assets/css/animate.css') }}">
<!-- Magnific Popup Css -->
<link rel="stylesheet" href="{{ asset('assets/css/magnific-popup.css') }}">
<!-- Flat Picker Css -->
<link rel="stylesheet" href="{{ asset('assets/css/flatpicker.css') }}">
<!-- Nice Select Css -->
<link rel="stylesheet" href="{{ asset('assets/css/nice-select.css') }}">
<!-- Main Stylesheet -->
<link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">
<link rel="stylesheet" href="{{ asset('assets/css/shots.css') }}">
<!-- Scroll Bar Color Stylesheet -->
<link rel="stylesheet" href="{{ asset('assets/css/geral.css') }}">
<!-- Language selector Stylesheet -->
<link rel="stylesheet" href="{{ asset('assets/css/languageSelector.css') }}">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

<style>
    .dt-length, .dt-paging {
        display: none;
    }
</style>
