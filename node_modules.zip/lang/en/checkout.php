<?php

return [
    'checkout_details' => 'Checkout Details',
    'reserve_information' => 'Reserve Information',
    'submit' => 'Submit',
    'tour_details' => 'Tour Details',
    'tour_name' => 'Tour Name',
    'date' => 'Date',
    'desired_boat' => 'Desired Boat',
    'price' => 'Price',
];
