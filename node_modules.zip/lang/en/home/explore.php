<?php


return [

    'title' => 'Amazing Boat Experience',
    'hover' => 'Know More',

];
