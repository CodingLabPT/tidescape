<?php


return [

    'title' => 'Location',
    'dropdown_title' => 'Select a location',
    'no_location' => 'Please select a location!',

];
