<?php

return [
    'title' => 'Registered Emails in the Newsletter',
    'export' => 'Export Data',
    'no_newsletters' => 'No users registered in the Newsletter',
    'name' => 'Name',
    'phone' => 'Phone',
    'Status' => 'Status',
    'opt' => 'Options',
    'delete' => 'Delete',
    'reserve_detail' => 'Details',
    'delete_reserve' => 'Delete',

    'email' => "Email",
    'go_back' => 'Go Back',
    'are_you_sure_to_delete' => 'Are you sure to delete?',

];
