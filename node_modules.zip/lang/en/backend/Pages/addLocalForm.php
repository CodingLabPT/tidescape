<?php

return [
    'title'            => 'Add new location',
    'name_placeholder'  => 'Desired location',
    'submit_btn'        => 'Add',
    'go_back_btn'       => 'Go back',
];
