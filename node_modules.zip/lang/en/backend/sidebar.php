<?php

return [
    'booking_management' => 'Booking Management',
    'booking' => 'Bookings',
    'Calendar' => 'Calendar',
    'Users' => 'Users',
    'Admins' => 'Admins',
    'Newsletter' => 'Newsletter',
    'Messages' => 'Messages',

    'Tours' => 'Tours',
    'Tours2' => 'Tours',

    'Categories' => 'Categories',
    'Local' => 'Local',
    'Duration' => 'Duration',
    'Management' => 'Management',
];
