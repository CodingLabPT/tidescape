<?php

return [

    'newsletter_error'   => 'Este e-mail já está inscrito na nossa newsletter!',
    'newsletter_success' => 'Obrigado por se inscrever na nossa newsletter!',

];
