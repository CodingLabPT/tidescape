<?php

return[

    'title' => 'As minhas Mensagens',
    'no' => 'Sem mensagens disponíveis!!',
    'delete' => 'Mensagem eliminada com sucesso!',

];
