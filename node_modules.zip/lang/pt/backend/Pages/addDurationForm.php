<?php

return[
    'title'            => 'Adicionar nova duração em horas',
    'name_placeholder'  => 'duração desejada (horas)',
    'submit_btn'        => 'Adicionar',
    'go_back_btn'       => 'Voltar',
];
