<?php

return [
    'newsletter_subject'         => 'Inscrição na newsletter',
    'reserves_subject'           => 'Reserva pendente de confirmação',
    'register_subject'           => 'Registo efetuado com sucesso',
    'contact_subject'            => 'Envio de mensagem do formulário de contacto',
    'contact_response_subject'   => 'Resposta a mensagem do formulário contacto',
    'validation_reserve_subject' => 'Reserva validada',
    'admin_reserve_subject'      => 'Reserva efetuada pelo admin!',
    'admin_register_subject'     => 'Registo efetuado por admin!',
];
