<?php

return [
    'title1'            => 'Agregar',
    'title2'            => 'Agregar nueva duración en horas',
    'name_placeholder'  => 'duración deseada (horas)',
    'submit_btn'        => 'Agregar',
    'go_back_btn'       => 'Volver',
];
