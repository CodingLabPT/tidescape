<?php

return [
    'booking_management' => 'Gestión de Reservas',
    'my_booking' => 'Mis Reservas',
    'calendar' => 'Calendario',

    'contacts' => 'Contactos',
    'my_messages' => 'Mis Mensajes',
    'newsletter' => 'Boletín Informativo',
    'my_reserves' => 'Mis Reservas',
    'sem_registo' => 'Sin Registro',
    'com_registo' => 'Registrado',

    'profile' => 'Perfil',
    'sair' => 'Salir',
];
