<?php

return[
    'booking_management' => 'Gestión de Reservas',
    'booking' => 'Reservas',
    'Calendar' => 'Calendario',
    'Users' => 'Usuarios',
    'Admins' => 'Administradores',
    'Newsletter' => 'Boletín informativo',
    'Messages' => 'Mensajes',

    'Tours' => 'Passeios',
    'Tours2' => 'Passeios',

    'Categories' => 'Categorias',
    'Local' => 'Local',
    'Duration' => 'Duratión',
    'Management'    => 'Gestíon',

];
