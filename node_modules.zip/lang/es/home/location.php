<?php


return [

    'title' => 'Localización',
    'dropdown_title' => 'Seleccionar una localización',
    'no_location' => 'Por favor, seleccione una ubicación!'
];
