<?php

return [
    'title' => '¡Reserva eventos, tours o viajes para tu próxima aventura.',
    'subtitle' => '¡Explora y crea recuerdos sin esfuerzo con nuestra plataforma, ¡donde el mundo es tu próximo destino!',
    'number' => '4.8/5(2380)',
    'reviews' => 'reseñas de Trustpilot',
];
