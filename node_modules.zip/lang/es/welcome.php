<?php


return [

    'welcome' => 'bienvenido',
    'admin_painel' => 'Admin Painel',

];
